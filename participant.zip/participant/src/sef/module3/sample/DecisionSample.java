package sef.module3.sample;

public class DecisionSample {
	
	public static void main(String[] args) {
		
		int theNumber = 1;
		
		if(theNumber == 1){
			System.out.println("The value of theNumber is 1");
		} else {
			System.out.println("The value of theNumber is not 1");
		}
	}
}
