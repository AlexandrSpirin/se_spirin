package sef.module6.sample;

public interface Speaker {

	public String introduce();
}
