package sef.module11.activity;

public interface TextEditor {
	
	void saveAs(String text);
	
	String typeIn();

}
