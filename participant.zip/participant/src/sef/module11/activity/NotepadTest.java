package sef.module11.activity;

import junit.framework.TestCase;

public class NotepadTest extends TestCase {

	public void testSaveAs() {
		fail("Not yet implemented");
	}

	public void testTypeIn() {
		fail("Not yet implemented");
	}

}
