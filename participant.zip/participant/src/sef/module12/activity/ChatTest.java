package sef.module12.activity;

import junit.framework.TestCase;

public class ChatTest extends TestCase {

	public void testAddUser() {
		fail("Not yet implemented");
	}

	public void testAddMessage() {
		fail("Not yet implemented");
	}

}
