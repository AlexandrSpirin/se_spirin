package sef.module5.sample;

public class WorkerImplA implements Worker{
	
	
	public void doWork(){
		System.out.println("Doing type-A work");
	}

}
