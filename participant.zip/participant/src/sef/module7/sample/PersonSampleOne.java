package sef.module7.sample;

public class PersonSampleOne {
	String name;
	int age;
}
