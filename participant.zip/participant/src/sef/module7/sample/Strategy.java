package sef.module7.sample;

public interface Strategy {

	public void execute();
}
