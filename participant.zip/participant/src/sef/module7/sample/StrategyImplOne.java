package sef.module7.sample;

public class StrategyImplOne implements Strategy {
	
	@Override
	public final void execute() {
		
		System.out.println("Pincer movement!");
	}

}
