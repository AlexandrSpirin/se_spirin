package sef.module7.activity;

import junit.framework.TestCase;

public class DenominationTest extends TestCase {
	
	DenominationTest1 runTest = new DenominationTest1();
	
	
	public void testCreateDenomination(){
		runTest.testCreateDenomination();
	}

}
