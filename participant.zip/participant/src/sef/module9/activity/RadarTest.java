package sef.module9.activity;

import junit.framework.TestCase;

public class RadarTest extends TestCase{
	
	RadarTest1 runTest = new RadarTest1();
	
		public void testRadar(){
			runTest.testRadar();					
		}
		
		public void testRemove(){
			runTest.testRemove();		
		}
		
		public void testGetList(){
			runTest.testGetList();
		}
		
		public void testGetSortedList(){
			runTest.testGetSortedList();			
		}
}
