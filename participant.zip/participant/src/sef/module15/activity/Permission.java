package sef.module15.activity;

public enum Permission {
	READ,
	WRITE,
	CREATE,
	DELETE,
	EXECUTE;
	
}
