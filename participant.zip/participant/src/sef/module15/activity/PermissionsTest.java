package sef.module15.activity;

import junit.framework.TestCase;

public class PermissionsTest extends TestCase {
	
	PermissionsTest1 runTest = new PermissionsTest1();
	
	public void testPermissions(){
		runTest.testPermissions();	
	}
}
