package sef.module15.sample;

public enum Seasons {
	SPRING, SUMMER, FALL, WINTER
}
